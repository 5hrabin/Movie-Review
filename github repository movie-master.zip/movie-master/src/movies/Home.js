import React, { Component, Suspense } from "react";
import Axios from "axios";
import PopularMovies from "./PopularMovies";
import {CounterConsumer} from '../component/Context'
import Hooks from "./Hooks"

const OtherComponent = React.lazy(() => import("../component/OtherComponent"));

class HomePage extends Component {
  constructor() {
    super();
    this.state = {
      popularMovies: []
    };
  }
  componentDidMount() {
    // Ajax request
    // get method => getting data from backend
    // post method => posting data to server
    // delete method/request
    // put and patch method => update ko lag
    this.getMovies();
    console.log("CDM");
  }
  getMovies = () => {
    Axios.get(
      "https://api.themoviedb.org/3/movie/popular?api_key=02689249b40636b114a2add6006bff65&language=en-US&page=1"
    ).then(movies => this.setState({ popularMovies: movies.data.results }));
  };
  handleMovie = movie => {
    this.props.movie(movie);
  }; 
  
  render() {
    return (
   <CounterConsumer>
     {value =>{
       console.log(value);
       return(
        <React.Fragment>
          <Suspense fallback={<div>Loading...</div>}>
        <OtherComponent />
      </Suspense>
        <PopularMovies
          popular={this.state.popularMovies}
          movie={this.handleMovie}
        />
        <h1 onClick={value.handleIncrement}>Your counter is: {value.count}</h1>
      </React.Fragment>
       )
     }}
   </CounterConsumer>
    );
  }
}

export default HomePage;
