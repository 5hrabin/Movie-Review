import React, { Component } from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import Navbars from "./Navbar";
import HomePage from "./Home";
import MoviesDetail from "./SingleMovie";
import Hooks from "./Hooks"

class Main extends Component {
  constructor() {
    super();
    this.state = {singleMovies: {}};
  }
  handleMovie = movie => {
    this.setState({ singleMovies: movie });
  };
  render() {
    return (
      <React.Fragment>
        <Navbars />
        <Switch>
          <Route
            path="/"
            exact
            render={() => 
               <HomePage movie={this.handleMovie} />}
              />
          <Route
            path="/details/:id"
            render={() => <MoviesDetail movie={this.state.singleMovies} />}
          />
        </Switch>
      </React.Fragment>
    );
  }
}

export default Main;
