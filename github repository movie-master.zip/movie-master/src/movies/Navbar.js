import React, { Component } from 'react';
import {Navbar,  Form, FormControl, Nav, Container} from "react-bootstrap";
import styled from "styled-components";
import{Link} from "react-router-dom";
class Navbars extends Component {

    render() { 
        return ( 
           
         <NavWrapper>
             <Container>
             <Navbar expand="lg">
            <Navbar.Brand href="https://yts.mx/">DOWNLOAD MOVIES</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">               
              <Form inline>
                <FormControl type="text" placeholder="Search" className="mr-sm-2" />
              </Form>
              <Nav className="mr-auto">
              </Nav>
                <Link to="/" className="nav-link">Home</Link>
                <Link to="/" className="nav-link">Movies</Link>
            </Navbar.Collapse>
          </Navbar>

             </Container>
         </NavWrapper>
         );
    }
}
 
const NavWrapper= styled.section`
  background-color: #2774c2;
  .nav-link{
      color: #fff !important;
  }
`;
export default Navbars;