import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";

class MoviesDetail extends Component {
  render() {
    return (
      <Container>
        <Row>
          <Col md="4">
            <img
              src={`https://image.tmdb.org/t/p/w500/${this.props.movie.backdrop_path}`}
              alt=""
            />
          </Col>
          <Col md="4"></Col>
        </Row>
      </Container>
    );
  }
}

export default MoviesDetail;
