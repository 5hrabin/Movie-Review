import React, {useState, useEffect} from "react";
import useToggle from "./useToggle"


function Hooks(props){
    const[count, setCount]= useState(0);
    const[todo, setTodo]= useState([]);
    const[name, setName]= useToggle(false);
    const[like, setLike]= useToggle(false);
    function increment(){
        setCount(count+1);
    }

    useEffect(()=>{
        console.log("componentdid mount run")
        fetch("https://jsonplaceholder.typicode.com/todos")
        .then(response=>response.json())
        .then(json=>setTodo(json));

        // return()=>{
        //     console.log("clean up")
        // }
    }, []);

    console.log("render run");
    console.log(props);

    return (
        <div>
    <h1 onClick={increment}>Your counter is: {count}</h1>
    <h1 onClick={setName}> {name ? "Ram": "Hari"}</h1>
    <h1 onClick={setLike}> {like ? "Like": "Dislike"}</h1>
    </div>
    )}

export default Hooks;