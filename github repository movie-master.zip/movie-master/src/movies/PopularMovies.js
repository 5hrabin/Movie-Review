import React, { Component } from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import { Link } from "react-router-dom";

class PopularMovies extends Component {
  state = {};
  render() {
    return (
      <Container className="mt-5">
        <h1>Popular Movies</h1>
        <Row>
          {this.props.popular.map(movie => {
            return (
              <Col md="3" onClick={() => this.props.movie(movie)}>
                <Link to={`/details/${movie.id}`}>
                  <Card>
                    <Card.Img
                      variant="top"
                      src={`https://image.tmdb.org/t/p/w500/${movie.backdrop_path}`}
                    />
                    <Card.Body>
                      <Card.Title>{movie.title}</Card.Title>
                    </Card.Body>
                  </Card>
                </Link>
              </Col>
            );
          })}
        </Row>
      </Container>
    );
  }
}

export default PopularMovies;
