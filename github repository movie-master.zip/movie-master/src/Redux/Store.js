import {createStore, applyMiddleware} from "redux"
import logger from "redux-logger"
import{composeWithDevTools} from "redux-devtools-extension"

import RootReducer from "./RootReduce"

const middleware=[logger]

const store= createStore(
    RootReducer,
    composeWithDevTools(applyMiddleware(...middleware))
)

export default store;
