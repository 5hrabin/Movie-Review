import { combineReducers } from "redux"
import CounterReducer from "./Counter/CounterReducer"


export default combineReducers({
count: CounterReducer
})