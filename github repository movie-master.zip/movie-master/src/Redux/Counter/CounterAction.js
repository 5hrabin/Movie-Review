export const setCounter=count=>({
    type:'SET_COUNTER',
    payload:count
})
