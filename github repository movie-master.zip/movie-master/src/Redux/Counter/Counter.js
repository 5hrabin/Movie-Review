import React, { Component } from 'react';
import {connect} from "react-redux"
import{setCounter} from "./CounterAction"

class Counter extends Component {
    render() { 
        console.log(this.props)
        return(
        <h1 onClick={()=>this.props.setCounter(this.props.count+1)}>Your Count Is: {this.props.count} </h1>
         );
    }
}
 
const mapstatetoprop=state=>({
    count:state.count.count
})

const mapdispatchtoprops=dispatch=>({
    setCounter:count=>dispatch(setCounter(count))
})
export default connect(mapstatetoprop,mapdispatchtoprops)(Counter);