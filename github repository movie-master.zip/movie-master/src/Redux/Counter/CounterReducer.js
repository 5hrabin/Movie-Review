
const initialState={
    count:0
}

const CounterReducer=(state=initialState,action)=>{
    switch(action.type){
        case 'SET_COUNTER':
             return{
                 ...state,
                 count:action.payload
                   }
          default:
              return state         
    }
}

export default CounterReducer;