import React from 'react';
import Navbar from './component/Navbar';
import Table from './component/Table';
// import Form from './component/Form';
import Swal from 'sweetalert2';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import uuid from "uuid";



class App extends React.Component{

  state = {

    record : [
      {id:uuid(), name:"Anjan", contact:"9865412365", address:"sunaul"},
      {id:uuid(), name:"Roshan", contact:"9868786197",address:"palpa"},
      {id:uuid(), name:"Shrabin", contact:"9862587412", address:"biratnagar"}
    ]
  };
  
  
  delete = id =>{
    console.log(id);
    console.log("id aayo")

    let filterData=this.state.record.filter(function(record){
      return( record.id!==id);
    });
        // console.log(filterData);
        

        Swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.value) {
            this.setState({record: filterData});
            toast.success("Successfully deleted")
            Swal.fire(
              'Deleted!',
              'Your file has been deleted.',
              'success'
            )
          }
        })
  };
  submitData=(formData)=>{
    // console.log("Parent call");
    console.log(formData);
    let newFormData = {id:uuid(),...formData}
    this.setState({record:[newFormData,...this.state.record]})
    toast.success("Form Data Submitted")
  }


          
  
            
  render() { 
    return ( 
      <div>
        <Navbar title="Record System"/>
        {/* <Form formData={this.submitData}/> */}

        <Table 
            delete={this.delete}
            record={this.state.record}/> 
         <ToastContainer autoClose={4000}/>   
      </div>
     );
  }
}

export default App;