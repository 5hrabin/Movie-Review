import React, { Component } from 'react';

class OtherComponent extends Component {
    render() { 
        return ( 
            <h1>OTHER COMPONENT</h1>
         );
    }
}
 
export default OtherComponent;