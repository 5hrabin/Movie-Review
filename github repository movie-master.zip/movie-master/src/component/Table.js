
import React from 'react';

class Table extends React.Component{
    
    handleDelete = (id) => {
        // console.log(id);
        // console.log("data rec")
        this.props.delete(id);

    }
    render() { 
        return ( 
                <div>
                     <table className="table table-bordered table-white w-50 mx-auto mt-5">
                        <thead>
                        <tr>
                        <th scope="col">name</th>
                        <th scope="col">contact</th>
                        <th scope="col">address</th>
                        </tr>
                        </thead>

                        <tbody>
                            {this.props.record.map(record=>{
                                return(
                                    <tr>
                                    <td>{record.name}</td>
                                    <td>{record.contact}</td>
                                    <td>{record.address}</td>
                                    <th scope="col">
                                        <i onClick={()=>this.handleDelete(record.id)}
                                        className="fas fa-trash"></i>
                                        <i className="fas fa-edit ml-5"></i>
                                        </th>
                                    </tr>           
                                );
                            })}
                        </tbody>    
                    </table>
                </div>           
         );
    }
}
 
export default Table;