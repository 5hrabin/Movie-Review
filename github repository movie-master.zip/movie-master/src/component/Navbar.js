import React from 'react'
class Navbar extends React.Component {

    render() { 
        return (  
              <div>
                    <nav className="navbar navbar-light bg-dark justify-content-between" >
                    <a className="navbar-brand" href="#" style={{color: "white"}}>
                        {this.props.title}</a>
                    
                    </nav> 
             </div>
        );
    }
}
 
export default Navbar;